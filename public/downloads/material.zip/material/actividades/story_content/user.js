function ExecuteScript(strId)
{
  switch (strId)
  {
      case "642t1Hw2QM9":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

